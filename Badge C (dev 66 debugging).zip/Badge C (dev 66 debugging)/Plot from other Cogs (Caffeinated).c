#include "simpletools.h"
#include "badgealpha.h"

void ball_A();
void ball_B();
void ball_C();
 
void main() 
{
  badge_setup();
  cog_run(ball_A, 128);
  cog_run(ball_B, 128);
  cog_run(ball_C, 512);
  
  int n = 0, dt;    
  while(1)
  {
    dt = 120 - abs(tilt_getY());
    led(n, ON);
    pause(dt);
    led(n, OFF);
    pause(dt);
    n++;    
    if(n == 6)
    {
      n = 0;
    }
  }      
}  

void ball_A() 
{
  int x = 0;
  int bw = 1;
  pause(10);
    
  while(1)
  {
    pause(7);
    x++;
    point(x, 64 - x/2, bw);
    if(x == 128)
    {
      x = 0;
      bw ^= 1;
    }          
  }      
}  


void ball_B() 
{
  int x = 0;
  int bw = 1;
  pause(5);
    
  while(1)
  {
    pause(3);
    x++;
    point(128 - x, 64 - x/2, bw);
    if(x == 128)
    {
      x = 0;
      bw ^= 1;
    }          
  }      
}  

void ball_C()
{
  int points = 100;
  int x[points], y[points], vx[points], vy[points], ox[points], oy[points];
  for(int i = 0; i < points; i++)
  {
    x[i] = 5 + rand() % 100;
    ox[i] = x[i];
    y[i] = 3 + rand() % 50;
    oy[i] = y[i];
    vx[i] = 1 + rand() % 3;
    vy[i] = 1 + rand() % 3;
  }    
  while (1)
  {
    for(int i = 0; i < points; i++)
    {
      point( x[i], y[i], 1);
    }    
    //screen_update();
    pause(10);  
   
    for(int i = 0; i < points; i++)
    {
      ox[i] = x[i];
      oy[i] = y[i];
      point( ox[i], oy[i], 0); 
    }
    //screen_update();

    for(int i = 0; i < points; i++)
    {
      x[i] = x[i] + vx[i];
      y[i] = y[i] + vy[i];
      
      if (x[i] >= 125 || x[i] <= 2) {
        vx[i] = -1 * vx[i];
      } 
      if (y[i] >= 62 || y[i] <= 2) {
        vy[i] = -1 * vy[i];
      }
    }         
  }
}

