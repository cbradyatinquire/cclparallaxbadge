#include "simpletools.h"
#include "badgealpha.h"

void main()
{
  // Touch pad monitoring
  // IMPORTANT - Not necessarily for beginners, 
  //             requires understanding of OR operation.
  badge_setup();
  print("Touch pads to control blue lights!\n");
  print("To exit pad mode, touch all 7 pads\n\n");
  clear();
  display("TOUCHPAD");
  pause(500);
  char_size(SMALL);
  cursor(0, 5);
  display("Touch all 7 pads   (to finish)");
  int history = 0, touch = 0;
  while(1)
  {
    touch = pads_get();
    history |= touch;
    leds_set(history);
    if(history == 0b1111111) break;
    cursor(0, 7);
    display("complete=%07b", history);
  } 
  char_size(BIG);
  cursor(0, 0);    
  display("PADS    Done!   ");     
  pause(800);
  leds_set(0b000000);
}


