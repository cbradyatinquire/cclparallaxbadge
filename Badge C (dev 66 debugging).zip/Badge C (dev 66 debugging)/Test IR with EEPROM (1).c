#include "simpletools.h"
#include "badgealpha.h"

info my = {{"Me"}, {"my@email.com"}, 0};
info kevin = {{"Kevin"}, {"kevin@minions.com"}, 0};
info stuart = {{"Stuart"}, {"stuart@minions.com"}, 0};
info bob = {{"Bob"}, {"bob@minions.com"}, 0};
info their;

void main()
{
  badge_setup();
  print("IR Test\n\n");
  ir_start();
  pause(500);
  clear();
  while(1)
  {
    char_size(BIG);
    cursor(0, 0); 
    display("IR Test ");
    char_size(SMALL);
    cursor(0, 4);
    display("IDs: P17,P16,P15");
    cursor(0, 5);
    display("UPLNK: OSH");
    cursor(0, 6);
    display("FORGET: P25");
    pause(100);
    memset(&their, 0, sizeof(info));
    int state = pads_get();
    switch(state)
    {
      case 0b1000000:
        clear();
        display("USB to host...");
        ee_displayContacts();
        display("done");
        break;
      case 0b0100000:
        rgb(L, BLUE);
        ir_send(&kevin);
        break;
      case 0b0010000:
        rgb(L, BLUE);
        ir_send(&stuart);
        break;
      case 0b0001000:
        rgb(L, BLUE);
        ir_send(&bob);
        break;
      case 0b0000100:
        ee_wipe();
        cursor(0, 7);
        display("Memory Cleared");
        pause(1000);
        clear();
        break;
    }        
    rgb(L, OFF);
    if(check_inbox() == 1)
    {
      message_get(&their);      
      clear();
      cursor(0, 0);
      display("New Contact!");
      cursor(0, 2);
      display("Name: %s ", their.name);
      //print("their.name = %s \n", their.name);
      cursor(0, 4);
      display("Email: %s ", their.email);
      //print("their.email = %s \n", their.email);
      cursor(0, 6);
      display("P27-SAVE");
      cursor(0, 7);
      display("P26-DISCARD");
      rgb(L, OFF);
      while(1)
      {
        state = pads_get();
        if(state == 0b0000001) 
        {
          ee_save(&their);
          clear_inbox();                              ///
          break;
        }
        if(state == 0b0000010) 
        {
          memset(&their, 0, sizeof(info));            ///
          clear_inbox();                              ///
          break;                                      ///
        }
      }        
      clear_inbox();                                  ///
      clear();
      rgb(R, OFF);
    }
  }    
}
