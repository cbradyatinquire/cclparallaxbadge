#include "simpletools.h"
#include "badgealpha.h"
#include "fdserial.h"

char handshake[5];
fdserial *port;

info my = {{"Me"}, {"my@email.com"}, 0};
info kevin = {{"Kevin"}, {"kevin@minions.com"}, 0};
info stuart = {{"Stuart"}, {"stuart@minions.com"}, 0};
info bob = {{"Bob"}, {"bob@minions.com"}, 0};
info their;

void main()
{
  // Initialize badge and serial connection
  badge_setup();
  simpleterm_close();
  port = fdserial_open(31, 30, 0, 115200);
  pause(3000);
  
  // Check for host upload, if not found, continue to main
  int attempt = 0;
  while (attempt < 5)
  {
    dprint(port, "Propeller\n");
    pause(1000);
    if (fdserial_rxCount(port) < 5)
    {
      fdserial_rxFlush(port);
      attempt++;
      continue;
    }
    else dscan(port, "%s", handshake);
    // Attempt handshake and listen to response
    if (strcmp(handshake, "H0st") == 0)
    {
      char_size(SMALL);
      cursor(0, 0);
      display("CONNECTED");
      cursor(0, 1);
      display("Uploading...");
      ee_uploadContacts(port);
      cursor(0, 2);
      display("Upload complete!");
      pause(5000);
      return;
    }      
    attempt++;
  }
  
  // Need to print for it to work?
  dprint(port, "IR Test\n");
  fdserial_close(port);
  
  ir_start();
  pause(500);
  clear();
  
  while(1)
  {
    char_size(BIG);
    cursor(0, 0); 
    display("IR Test ");
    char_size(SMALL);
    cursor(0, 4);
    display("IDs: P17,P16,P15");
    cursor(0, 5);
    display("FORGET: P25");
    pause(100);
    memset(&their, 0, sizeof(info));
    int state = pads_get();
    switch(state)
    {
      case 0b0100000:
        rgb(L, BLUE);
        ir_send(&kevin);
        break;
      case 0b0010000:
        rgb(L, BLUE);
        ir_send(&stuart);
        break;
      case 0b0001000:
        rgb(L, BLUE);
        ir_send(&bob);
        break;
      case 0b0000100:
        ee_wipe();
        cursor(0, 7);
        display("Memory Cleared");
        pause(1000);
        clear();
        break;
    }        
    rgb(L, OFF);
    if(check_inbox() == 1)
    {
      message_get(&their);      
      clear();
      cursor(0, 0);
      display("New Contact!");
      cursor(0, 2);
      display("Name: %s ", their.name);
      //print("their.name = %s \n", their.name);
      cursor(0, 4);
      display("Email: %s ", their.email);
      //print("their.email = %s \n", their.email);
      cursor(0, 6);
      display("P27-SAVE");
      cursor(0, 7);
      display("P26-DISCARD");
      rgb(L, OFF);
      while(1)
      {
        state = pads_get();
        if(state == 0b0000001) 
        {
          ee_save(&their);
          break;
        }
        if(state == 0b0000010) 
        {
          break;
        }
      }        
      clear();
      rgb(R, OFF);
    }
  }    
}