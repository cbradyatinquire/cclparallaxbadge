#include "simpletools.h"
#include "badgealpha.h"

void ball_A();
void ball_B();
void ball_C();
 
void main() 
{
  badge_setup();
  cog_run(ball_A, 128);
  cog_run(ball_B, 128);
  cog_run(ball_C, 128);
}  

void ball_A()
{
  srand(123);
  int x, y, vx, vy, ox, oy, dt, t;
  x = 5 + rand() % 100;
  ox = x;
  y = 3 + rand() % 50;
  oy = y;
  vx = 1 + rand() % 3;
  vy = 1 + rand() % 3;
  dt = 15 + rand() %10;
  while (1)
  {
    point( x, y, 1);
    pause(dt);  
   
    ox = x;
    oy = y;
    point(ox, oy, 0); 

    x = x + vx;
    y = y + vy;
    
    if (x >= 125 || x <= 2) {
      vx = -1 * vx;
    } 
    if (y >= 62 || y <= 2) {
      vy = -1 * vy;
    }
  }
}


void ball_B()
{
  srand(456);
  int x, y, vx, vy, ox, oy, dt, t;
  x = 5 + rand() % 100;
  ox = x;
  y = 3 + rand() % 50;
  oy = y;
  vx = 1 + rand() % 3;
  vy = 1 + rand() % 3;
  dt = 15 + rand() %10;
  while (1)
  {
    point( x, y, 1);
    pause(dt);  
   
    ox = x;
    oy = y;
    point(ox, oy, 0); 

    x = x + vx;
    y = y + vy;
    
    if (x >= 125 || x <= 2) {
      vx = -1 * vx;
    } 
    if (y >= 62 || y <= 2) {
      vy = -1 * vy;
    }
  }
}

void ball_C()
{
  srand(789);
  int x, y, vx, vy, ox, oy, t, dt;
  x = 5 + rand() % 100;
  ox = x;
  y = 3 + rand() % 50;
  oy = y;
  vx = 1 + rand() % 3;
  vy = 1 + rand() % 3;
  dt = 15 + rand() %10;
  while (1)
  {
    point( x, y, 1);
    pause(dt);  
   
    ox = x;
    oy = y;
    point(ox, oy, 0); 

    x = x + vx;
    y = y + vy;
    
    if (x >= 125 || x <= 2) {
      vx = -1 * vx;
    } 
    if (y >= 62 || y <= 2) {
      vy = -1 * vy;
    }
  }
}

