#include "simpletools.h"
#include "badgealpha.h"

void ball_A();
void ball_B();
void ball_C();

static int *cog;
static int *lightCog;
int states;
 
void main() 
{
  badge_setup();
  //cog_run(ball_A, 128);
  //cog_run(ball_B, 128);
  
  pause(500);
  char_size(BIG);
  while(1)
  {
    cursor(0, 0);
    display("  Andy  Parallax");
    states = pads_get();
    if(states == 0b0100000)
    {
      if(cog == 0)
      {
        cog = cog_run(ball_C, 512);
      }
    }
    if(states == 0b0000001)
    {
      if(cog)
      {
        cog_end(cog);
        clear();
        pause(50);
        cog = 0;
      }
    }
    if(states == 0b0001000)
    {
      if(lightCog == 0)
      {
        lightCog = cog_run(ball_A, 512);
      }
    }
    if(states == 0b0000100)
    {
      if(lightCog)
      {
        cog_end(lightCog);
        //clear();
        pause(50);
        leds_set(0b000000);
        lightCog = 0;
      }
    }
  }
  //clear();    
}      

void ball_A()
{
  int n = 0, dt;    
  while(1)
  {
    dt = 20 + abs(tilt_getY());
    led(n, ON);
    pause(dt);
    led(n, OFF);
    pause(dt);
    n++;    
    if(n == 6)
    {
      n = 0;
    }
  }      
}


void ball_B()
{
  srand(456);
  int x, y, vx, vy, ox, oy, dt;
  x = 5 + rand() % 100;
  ox = x;
  y = 3 + rand() % 50;
  oy = y;
  vx = 1 + rand() % 3;
  vy = 1 + rand() % 3;
  dt = 15 + rand() %10;
  while (1)
  {
    point( x, y, 1);
    pause(dt);  
   
    ox = x;
    oy = y;
    point(ox, oy, 0); 

    x = x + vx;
    y = y + vy;
    
    if (x >= 125 || x <= 2) {
      vx = -1 * vx;
    } 
    if (y >= 62 || y <= 2) {
      vy = -1 * vy;
    }
  }
}

void ball_C()
{
  int points = 100;
  int x[points], y[points], vx[points], vy[points], ox[points], oy[points];
  for(int i = 0; i < points; i++)
  {
    x[i] = 5 + rand() % 100;
    ox[i] = x[i];
    y[i] = 3 + rand() % 50;
    oy[i] = y[i];
    vx[i] = 1 + rand() % 3;
    vy[i] = 1 + rand() % 3;
  }    
  while (1)
  {
    for(int i = 0; i < points; i++)
    {
      point( x[i], y[i], 1);
    }    
    //screen_update();
    pause(10);  
   
    for(int i = 0; i < points; i++)
    {
      ox[i] = x[i];
      oy[i] = y[i];
      point( ox[i], oy[i], 0); 
    }
    //screen_update();

    for(int i = 0; i < points; i++)
    {
      x[i] = x[i] + vx[i];
      y[i] = y[i] + vy[i];
      
      if (x[i] >= 125 || x[i] <= 2) {
        vx[i] = -1 * vx[i];
      } 
      if (y[i] >= 62 || y[i] <= 2) {
        vy[i] = -1 * vy[i];
      }
    }         
  }
}

