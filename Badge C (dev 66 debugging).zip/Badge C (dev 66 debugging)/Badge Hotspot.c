#include "simpletools.h"
#include "badgealpha.h"

info my = {{"Me"}, {"my@email.com"}, 0};

// Use hotspotn for the name, where n is some positive integer.
info hotspot = {{"hotspot3"}, {"hotspot3@domain.com"}, 0};

info their;

//fdserial *term;

void main()
{
  badge_setup();
  ir_start();
  print("IR Test\n\n");
  pause(500);
  clear();
  while(1)
  {
    char_size(BIG);
    cursor(0, 0); 
    display("HOTSPOT3");
    memset(&their, 0, sizeof(info));
    //int state = pads_get();
    ir_send(&hotspot);
    // NOTE: CNT increments independently at 80 MHz
    int t = CNT;                              // Mark time now
    int dt = CLKFREQ * 2;                     // Set timeout time
    while(1)
    {
      if(CNT - t > dt)                        // If timed out, break
      {
        print("Timed out\n");
        break;
      }        
      if(check_inbox() == 1)
      {
        t = CNT;                              // Reset timer
        message_get(&their);      
        if(!strcmp(their.name, "txDone"))
        {
          print("End of records.\n\n");
          cursor(0, 1);
          display("Thanks!");
          pause(5000);
          rgb(L, OFF);
          rgb(R, OFF);
          clear();
          break;
        }          
        print("Name: %s\n", their.name);
        print("Email: %s\n", their.email);
      }
    }              
  }
}
