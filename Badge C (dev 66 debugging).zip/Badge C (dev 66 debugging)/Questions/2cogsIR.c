#include "simpletools.h"
#include "badgealpha.h"

volatile info my = {"Stuart", "stuart@minions.com", 0};
volatile info their;

void receiveLoop();
void sendLoop();


void main()
{
  print("IR Test\n\n");
  ir_start();
  pause(500);
  clear();
  
  cog_run(sendLoop, 512);
  cog_run(receiveLoop, 512);
  
}


void sendLoop() {
 while(1)
  {
    char_size(BIG);
    cursor(0, 0); 
    display("IR Test ");
    char_size(SMALL);
    cursor(0, 4);
    display("Send? Press OSH.");
    pause(100);
    memset(&their, 0, sizeof(info));
    if(pad(6) == 1)
    {
      rgb(L, BLUE);
      ir_send(&my);
      rgb(L, OFF);
    }
  }//while
  
}  


void receiveLoop() {
 while(1)
  {
    if(check_inbox() == 1)
    {
      message_get(&their);      
      clear();
      cursor(0, 0);
      display("New Contact!");
      cursor(0, 2);
      display("Name: %s ", their.name);
      print("their.name = %s \n", their.name);
      cursor(0, 4);
      display("Email: %s ", their.email);
      print("their.email = %s \n", their.email);
      cursor(0, 7);
      display("Again? Pad P27.");
      rgb(L, OFF);
      while(pad(0) != 1);
      clear();
      rgb(R, OFF);
    }
  } 
}  