#include "simpletools.h"
#include "badgealpha.h"

char handshake[6];
char test;
char hs_key[6] = { "hello" };

void main() 
{ 
  cursor(0, 4);
  char_size(SMALL);
  while(strcmp(handshake, hs_key) != 0)
  {
    print("Hello from Propeller\n");
    pause(1000);
    //getStr(handshake, 5);
    scan("%s", handshake);
    display(handshake);
    print(handshake);
    pause(2000);
  }
  clear();
  cursor(0, 4);
  display("CONNECTED");
}