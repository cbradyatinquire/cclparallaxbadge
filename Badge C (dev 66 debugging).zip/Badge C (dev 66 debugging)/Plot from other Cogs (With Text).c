#include "simpletools.h"
#include "badgealpha.h"

void ball_A();
void ball_B();
void ball_C();
 
void main() 
{
  badge_setup();
  cog_run(ball_A, 128);
  cog_run(ball_B, 128);
  cog_run(ball_C, 128);
  
  pause(500);
  char_size(SMALL);
  int x, y, z;
  while(pad(6) == 0)
  {
    tilt_get(&x, &y, &z);
    cursor(5, 2);
    display("x = %3d " , x);
    cursor(5, 3);
    display("y = %3d ", y);
    cursor(5, 4);
    display("z = %3d ", z);
    cursor(0, 7);
    display("Exit? Press OSH");
    pause(100);
  }
  clear();    
}      

void ball_A()
{
  srand(123);
  int x, y, vx, vy, ox, oy, dt;
  x = 5 + rand() % 100;
  ox = x;
  y = 3 + rand() % 50;
  oy = y;
  vx = 1 + rand() % 3;
  vy = 1 + rand() % 3;
  dt = 15 + rand() %10;
  while (1)
  {
    point( x, y, 1);
    pause(dt);  
   
    ox = x;
    oy = y;
    point(ox, oy, 0); 

    x = x + vx;
    y = y + vy;
    
    if (x >= 125 || x <= 2) {
      vx = -1 * vx;
    } 
    if (y >= 62 || y <= 2) {
      vy = -1 * vy;
    }
  }
}


void ball_B()
{
  srand(456);
  int x, y, vx, vy, ox, oy, dt;
  x = 5 + rand() % 100;
  ox = x;
  y = 3 + rand() % 50;
  oy = y;
  vx = 1 + rand() % 3;
  vy = 1 + rand() % 3;
  dt = 15 + rand() %10;
  while (1)
  {
    point( x, y, 1);
    pause(dt);  
   
    ox = x;
    oy = y;
    point(ox, oy, 0); 

    x = x + vx;
    y = y + vy;
    
    if (x >= 125 || x <= 2) {
      vx = -1 * vx;
    } 
    if (y >= 62 || y <= 2) {
      vy = -1 * vy;
    }
  }
}

void ball_C()
{
  srand(789);
  int x, y, vx, vy, ox, oy, dt;
  x = 5 + rand() % 100;
  ox = x;
  y = 3 + rand() % 50;
  oy = y;
  vx = 1 + rand() % 3;
  vy = 1 + rand() % 3;
  dt = 15 + rand() %10;
  while (1)
  {
    point( x, y, 1);
    pause(dt);  
   
    ox = x;
    oy = y;
    point(ox, oy, 0); 

    x = x + vx;
    y = y + vy;
    
    if (x >= 125 || x <= 2) {
      vx = -1 * vx;
    } 
    if (y >= 62 || y <= 2) {
      vy = -1 * vy;
    }
  }
}

