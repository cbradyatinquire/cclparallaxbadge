/*
  Beginner API Tests.c
  Explores API support of beginner learning curves.
*/

#include "simpletools.h"
#include "badgealpha.h"

void main()
{
  badge_setup();
  clear();
  char_size(BIG); 

  // Touch pad monitoring
  print("Touch pads to control blue lights!\n");
  print("To exit pad mode, touch all 7 pads\n\n");
  clear();
  display("TOUCHPAD");
  pause(500);
  char_size(SMALL);
  cursor(0, 4);
  display("EXIT: Touch all 7       pads");
  cursor(0, 6);
  display("PAD:   6543210");
  cursor(0, 7);
  display("STATE:");
  int history = 0, touch = 0;
  while(1)
  {
    touch = pads_get();
    int state;
    for(int i = 0; i <= 6; i++)
    {
      state = get_bit(i, touch);
      if(state == 1)
      {
        set_bit(i, &history);
        led(i, ON);
      }        
    }      
    cursor(7, 7);
    display("%07b", history);
    if(history == 0b1111111) break;
  } 
  char_size(BIG);
  cursor(0, 0);    
  display("PADS    Done!   ");     
  pause(800);
  leds_set(0b000000);
}


